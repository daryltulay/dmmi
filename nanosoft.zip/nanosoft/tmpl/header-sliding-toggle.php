<?php // if ( has_nav_menu( 'sliding' ) ): ?>
	<a href="javascript:;" data-target="off-canvas-right" class="off-canvas-toggle">
		<span></span>
	</a>
<?php // endif; ?>